Remote Display V3.3
(c)2010 Toradex AG
===========================

Description
===========================
This tool allows to watch and operate the Colibri's desktop on a host PC.
The PC and the Colibri must be connected to the same subnet of an Ethernet network.

NOTE: In this version The PC is the Client and the Colibri is the Server that will wait for a connection (it also will send broadcasts to show its presence).

Installation Instructions (Manual Start)
===========================================
1. Copy CerDisp.exe to any folder on the Colibri. Execute it and click the "Start" button.

2. Copy CerHost.exe to any location on your PC, and execute it. Choose the Menu "File -> Connect".
   After a few seconds, the Colibri module will show up in the list of available devices. Select the device and press OK.


Installation Instructions (Automatic Start)
===========================================
1. Copy the folders \AutoRun\ and \AutoCopy\ either
	* to the Colibri \FlashDisk\ folder
	* to the root folder of a USB pen drive
	* to the root folder of an SD/MMC card
   Whenever you boot the Colibri, or insert the pen drive or SD/MMC card, the cerdisp.exe tool is automatically run on the Colibri.

2. Copy CerHost.exe to any location on your PC, and execute it. Choose the Menu "File -> Connect".
   After a few seconds, the Colibri module will show up in the list of available devices. Select the device and press OK.

Changelog
=========
v.3.3 Fixed an issue that prevented the tool from working when started at boot, set -w parameter as default command line in autorun shortcut
v.3.2 Added -w parameter to start broadcasting only when a valid network connection is detected (may help if cerdisp can't connect if started at boot)
      Added -a parm to check that the connected network adapter is the one onboard or RNDIS